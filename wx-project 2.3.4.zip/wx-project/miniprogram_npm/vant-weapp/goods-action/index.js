import { VantComponent } from '../common/component';
VantComponent();